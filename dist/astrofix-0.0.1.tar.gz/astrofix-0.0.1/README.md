# astrofix
Astro-Fix is an astronomical image correction algorithm based on Gaussian Process Regression.  
Our paper can be found at 
